#!/bin/bash

set -e

exec &> >(tee -a log.txt)

echo 
echo "Starting setup..."
date 
echo

echo "Setting default namespace to 'inoqulate'..." 
if ! kubectl config set-context --current --namespace=inoqulate; then
    echo "Please set the cluster context to the inoQulate AKS cluster first."
    exit 1
fi

echo "Checking needed files and directories..."

if [ ! -d "../management-ca" ]; then
    echo "Error: Directory ../management-ca not found" 
    exit 1
fi
MANAGEMENTCA_PATH="../management-ca"

if [ ! -d "../signserver-tls-keystore" ]; then
    echo "Error: Directory ../signserver-tls-keystore not found" 
    exit 1
fi
TLS_KEYSTORE_PATH="../signserver-tls-keystore/"

if [ ! -d "../servicerunner-tls-truststore/" ]; then
    echo "Making directory ../servicerunner-tls-truststore" 
    mkdir -p "../servicerunner-tls-truststore/" 
fi
SERVICERUNNER_TRUSTSTORE_PATH="../servicerunner-tls-truststore/"

if [ ! -d "../data/toInoQulate" ]; then
    echo "Making directory ../data/toInoQulate" 
    mkdir -p "../data/toInoQulate" 
fi

if [ ! -f ./scripts/1_ejbca.sh ]; then
    echo "Error: ./scripts/1_ejbca.sh not found" 
    exit 1
fi

if [ ! -f ./scripts/2_signserver.sh ]; then
    echo "Error: ./scripts/2_signserver.sh not found" 
    exit 1
fi

if [ ! -f ./scripts/3_ejbca.sh ]; then
    echo "Error: ./scripts/3_ejbca.sh not found" 
    exit 1
fi

if [ ! -f ./scripts/4_signserver.sh ]; then
    echo "Error: ./scripts/4_signserver.sh not found" 
    exit 1
fi

if [ ! -f ./scripts/testrun.sh ]; then
    echo "Error: ./scripts/testrun.sh not found" 
    exit 1
fi

echo "Checking EJBCA is ready..."
EJBCA_HOSTNAME="$(helm get values $(helm list -q) -o json | jq -r .ejbca.service.hostname)"
if [ -z "${EJBCA_HOSTNAME}" ]; then
    echo "Could not get EJBCA Hostname."
    exit 1
fi

for i in {1..10}; do
    if status="$(curl -k "https://${EJBCA_HOSTNAME}/ejbca/publicweb/healthcheck/ejbcahealth")"; then
        echo "${status}"
        if [ "${status}" == "ALLOK" ] ; then
            break
        fi
    fi
    
    if [ "$i" -eq 10 ]; then
        echo "EJBCA is not ready. Please try again later."
        exit 1
    fi
    echo "Trying again in 30 seconds..."
    sleep 30
done
echo

echo "Running ./scripts/1_ejbca.sh..."
kubectl exec -i deployment/ejbca bash < ./scripts/1_ejbca.sh 

echo "Running ./scripts/2_signserver.sh..."
kubectl exec -i deployment/signserver bash < ./scripts/2_signserver.sh 

echo "Running ./scripts/3_ejbca.sh..."
kubectl exec -i deployment/ejbca bash < ./scripts/3_ejbca.sh 

echo "Running ./scripts/4_signserver.sh..."
kubectl exec -i deployment/signserver bash < ./scripts/4_signserver.sh 

echo "Installing ManagementCA.crt into Signserver..."
cp "./ManagementCA.crt" "${MANAGEMENTCA_PATH}"

echo "Creating Java Truststore for ServiceRunner..."
TRUSTSTORE_PASSWORD="$(kubectl get secret servicerunner-truststore-creds -o jsonpath='{.data.password}' | base64 --decode)"
keytool -keystore "${SERVICERUNNER_TRUSTSTORE_PATH}/ManagementCA-chain.jks" -storepass "${TRUSTSTORE_PASSWORD}" -alias managementca -import -file ./ManagementCA-chain.pem -noprompt

echo "Installing TLS Certificate for Signserver..."
mv "./signserver.jks" "${TLS_KEYSTORE_PATH}/server.jks"
echo "$(kubectl get secret signserver-creds -o jsonpath='{.data.tlspassword}' | base64 --decode)" > "${TLS_KEYSTORE_PATH}/server.storepasswd"

echo "Restarting EJBCA and Signserver to effect changes..."
kubectl rollout restart deployment ejbca signserver

sleep 120
echo "Setup process complete!"
date
echo
for i in {1..10}; do
    if ./scripts/testrun.sh; then
        break
    fi

    if [ "$i" -eq 10 ]; then
        echo "Signserver is not ready. Try again later by running ./scripts/testrun.sh"
        exit 1
    fi
    echo "Trying again in 30 seconds..."
    sleep 30
done

echo "inoQulate is now ready to be used!"
date
echo