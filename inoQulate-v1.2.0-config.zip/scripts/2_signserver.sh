#!/bin/bash

set -e

# Init softhsm tokens for Signserver
echo "Initialising Signserver SPP-SoftHSM with new token..."
softhsm2-util --init-token --label newtoken --free --pin "${SOFTHSM_PIN}" --so-pin "${SOFTHSM_SO_PIN}"

# Create CryptoWorker in Signserver
echo "Creating CrytoWorker..."
signserver setproperties "/config/workers/CryptoWorker.properties"
echo "Setting PIN for CrytoWorker..."
signserver setproperty CryptoWorker PIN "${SOFTHSM_PIN}" > /dev/null
signserver reload CryptoWorker

# Generate keys
echo "Generating keys for CryptoWorker..."
signserver generatekey CryptoWorker -keyalg ECDSA -keyspec secp256r1 -alias testkey
signserver generatekey CryptoWorker -keyalg ECDSA -keyspec secp256r1 -alias ts0001

# Create TimeStampSigner
echo "Creating TimeStampSigner Worker..."
signserver setproperties "/config/workers/TimeStampSigner.properties"

echo "Generating Certificate Signing Request for TimeStampSignserver Worker..."
signserver generatecertreq TimeStampSigner "CN=${SERVICE_CN}" "SHA256withECDSA" "/config/TimeStampSigner.p10"