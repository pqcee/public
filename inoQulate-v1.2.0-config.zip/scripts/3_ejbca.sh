#!/bin/bash

set -e

# Sign CSR
echo "${CA_NAME} is signing CSR for TimeStampSignserver Worker..."
ejbca.sh ra addendentity --username Timestamper --dn "CN=${SERVICE_CN}" --token USERGENERATED --type 1 --caname "${CA_NAME}" --certprofile "inoQulate TIMESTAMPER" --eeprofile TIMESTAMPER --password "${SIGNSERVER_ENTITY_PASSWORD}"
ejbca.sh createcert --username Timestamper --password "${SIGNSERVER_ENTITY_PASSWORD}" -c "/config/TimeStampSigner.p10" -f "/config/TimeStampSigner.pem"
ejbca.sh ca getcacert --caname "${CA_NAME}" --include-full-chain -f "/config/${CA_NAME}-chain.pem"

echo "Creating certificate chain for TimeStampSigner Worker..."
cat "/config/${CA_NAME}-chain.pem" "/config/TimeStampSigner.pem" > "/config/TimeStampSigner-chain.pem"