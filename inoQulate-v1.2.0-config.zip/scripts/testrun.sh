#!/bin/bash

set -e

echo "Attempting test run..."
date
echo
echo "Checking Signserver is ready..."

SIGNSERVER_HOSTNAME="$(helm get values $(helm list -q) -o json | jq -r .signserver.service.hostname)"
if [ -z "${SIGNSERVER_HOSTNAME}" ]; then
    echo "Could not get Signserver Hostname."
    echo "Have you set the cluster context to the inoQulate AKS cluster?"
    exit 1
fi

if ! status="$(curl -k "https://${SIGNSERVER_HOSTNAME}/signserver/healthcheck/signserverhealth")"; then
    echo "Could not reach Signserver."
    exit 1
fi

echo "${status}"
if [ "${status}" != "ALLOK" ]; then
    echo "Signserver is not ready."
    exit 1
fi

echo
echo "Removing ../data/{done,toInoQulate,error,inoQulated}/sample.pdf"
rm -fv ../data/{done,toInoQulate,error,inoQulated}/sample.pdf

echo "Executing test run..."
cp "sample.pdf" "../data/toInoQulate"
JOB_NAME="testrun-$(date +%s)"
kubectl create job "${JOB_NAME}" --from=cronjob/servicerunner

echo "Waiting for run to complete..."
sleep 60

if [ -f "../data/inoQulated/sample.pdf" ]; then
    echo "Test run successful!"
else
    echo "Test run failed: did not find inoQulated sample.pdf in ../data/inoQulated."
    echo "Execute:"
    echo "  kubectl logs job/${JOB_NAME}"
    echo "for more details."
    exit 1
fi