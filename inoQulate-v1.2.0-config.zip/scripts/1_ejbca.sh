#!/bin/bash

set -e

# Import cert and end entity profiles
echo "Importing certificate profiles and end entity profiles used by ManagementCA..."
ejbca.sh ca importprofiles "/config/profiles/managementca" ManagementCA

# Add SuperAdmin
echo "Creating Client Certificate signed by ManagementCA..."
ejbca.sh ra addendentity --username superadmin --certprofile "inoQulate SuperAdmin" --eeprofile "SUPERADMIN" --dn "CN=SuperAdmin" --caname ManagementCA --type 1 --token P12 --password "${SUPERADMIN_PASSWORD}"
ejbca.sh ra setclearpwd superadmin "${SUPERADMIN_PASSWORD}"
ejbca.sh batch --keyalg rsa --keyspec 3072 -dir "/config"

# Remove public access role and add superadmin role
echo "Removing public unauthenticated access and adding Client Certificate authenticated access..."
ejbca.sh roles removerole 'Public Access Role'
ejbca.sh roles addrolemember --role 'Super Administrator Role' --caname ManagementCA --with CertificateAuthenticationToken:WITH_COMMONNAME --value SuperAdmin
ejbca.sh roles removeadmin --role 'Super Administrator Role' --caname "" --with PublicAccessAuthenticationToken:TRANSPORT_CONFIDENTIAL --value ""

# Get ManagementCA.crt and ManagementCA-chain.jks
echo "Downloading Management CA certificates..."
ejbca.sh ca getcacert --caname ManagementCA -der -f "/config/ManagementCA.crt"
ejbca.sh ca getcacert --caname ManagementCA --include-full-chain -f "/config/ManagementCA-chain.pem"

# Request Signserver TLS Cert
echo "Creating TLS certificate for Signserver signed by ManagementCA..."
ejbca.sh ra addendentity --username signserver --certprofile "inoQulate SERVER" --eeprofile SIGNSERVER --dn "CN=${SIGNSERVER_HOSTNAME}" --altname "DNSNAME=signserver,DNSNAME=${SIGNSERVER_HOSTNAME}" --caname ManagementCA --type 1 --token JKS --password "${SIGNSERVER_TLS_PASSWORD}"
ejbca.sh ra setclearpwd signserver "${SIGNSERVER_TLS_PASSWORD}"
ejbca.sh batch --keyalg rsa --keyspec 3072 -dir "/config"

# Init softhsm tokens for EJBCA
echo "Initialising EJBCA SPP-SoftHSM with new token..."
softhsm2-util --init-token --label newtoken --free --pin "${SOFTHSM_PIN}" --so-pin "${SOFTHSM_SO_PIN}"

# Create CryptoToken
echo "Creating a Crypto Token..."
ejbca.sh cryptotoken create --token "inoQulate Token" --pin "${SOFTHSM_PIN}" --autoactivate TRUE --type PKCS11CryptoToken --lib /usr/local/lib/softhsm/libsofthsm2.so --slotlabeltype SLOT_LABEL --slotlabel newtoken

# Generate key
echo "Generating key for Crypto Token..."
ejbca.sh cryptotoken generatekey --token "inoQulate Token" --alias signKey --keyspec secp256r1

# Create CA
echo "Creating ${CA_NAME}..."
echo certSignKey signKey >> token.properties
echo crlSignKey signKey >> token.properties
echo keyEncryptKey signKey >> token.properties
echo testKey signKey >> token.properties
echo defaultKey signKey >> token.properties
ejbca.sh ca init --caname "${CA_NAME}" --dn "CN=${CA_NAME}" --keytype ECDSA --keyspec secp256r1 --policy null -s SHA256withECDSA -v 1095 --tokenName "inoQulate Token" -certprofile "inoQulate ROOTCA" --tokenprop token.properties
ejbca.sh ca editca --caname "${CA_NAME}" --field "defaultCRLDistPoint" --value "https://${HTTPSERVER_HOSTNAME}/ejbca/publicweb/webdist/certdist?cmd=crl&issuer=CN%3D${CA_NAME_URLENCODED}"
ejbca.sh ca editca --caname "${CA_NAME}" --field "defaultOCSPServiceLocator" --value "https://${HTTPSERVER_HOSTNAME}/ejbca/publicweb/status/ocsp"

# Import inoQulate CA profiles
echo "Importing certificate profiles and end entity profiles used by ${CA_NAME}..."
ejbca.sh ca importprofiles /config/profiles/inoqulateca "${CA_NAME}"