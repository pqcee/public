#!/bin/bash

set -e

# Import signed CSR to TimeStampSigner
echo "Installing certificate chain into TimeStampSigner Worker..."
signserver uploadsignercertificatechain TimeStampSigner GLOB "/config/TimeStampSigner-chain.pem"
signserver reload TimeStampSigner